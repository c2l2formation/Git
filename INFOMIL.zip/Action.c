//   *****************************************************************************************************************************************
//   ****   PLEASE NOTE: This is a READ-ONLY representation of the actual script. For editing please press the "Develop Script" button.   ****
//   *****************************************************************************************************************************************

Action()
{
	lr_start_transaction("01_Connect");
	truclient_step("1", "Navigate to 'https://www.leclercdrive.fr/ '", "snapshot=Action_1.inf");
	lr_end_transaction("01_Connect",0);
	lr_start_transaction("02_Info");
	truclient_step("2", "Click on Prix E.Leclerc garantis JavaScript link", "snapshot=Action_2.inf");
	lr_end_transaction("02_Info",0);
	lr_start_transaction("03_Form");
	truclient_step("4", "Click on focusable (1)", "snapshot=Action_4.inf");
	truclient_step("5", "form (1)", "snapshot=Action_5.inf");
	{
		truclient_step("5.1", "Click on Entrez une ville ou code... textbox", "snapshot=Action_5.1.inf");
		truclient_step("5.2", "Type 75011 in Entrez une ville ou code... textbox", "snapshot=Action_5.2.inf");
		truclient_step("5.3", "Press key Enter on Entrez une ville ou code... textbox", "snapshot=Action_5.3.inf");
	}
	lr_end_transaction("03_Form",0);

	return 0;
}
